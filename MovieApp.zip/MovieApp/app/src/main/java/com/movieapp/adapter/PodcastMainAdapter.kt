package com.tRadioChaneloappp10.Adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.RecyclerView

import com.sportbettingguidetemplate.Data.Podcast
import com.sportbettingguidetemplate.R
import com.sportbettingguidetemplate.Util.Player
import com.sportbettingguidetemplate.databinding.CardPodcastBinding

class PodcastMainAdapter(val context: Context) : RecyclerView.Adapter<PodcastMainAdapter.ViewHolder>()  {

    val asyncListDiffer = AsyncListDiffer(this,
            PodcastDiffUtilCallback()
    )
    fun setData(newItems: List<Podcast>){
        asyncListDiffer.submitList(newItems)
    }
    inner class ViewHolder( binding: CardPodcastBinding) : RecyclerView.ViewHolder(binding.root) {


        val title_podcast_txt = binding.titlePodcastTxt
        val podcast_skb = binding.podcastSkb
        val play_stop_btn = binding.playStopBtn
        val puse_btn = binding.puseBtn


        fun bind(podcast: Podcast) {

            title_podcast_txt.text = podcast.name
            play_stop_btn.setOnClickListener {
                Player.play(context,podcast.link,podcast.id,play_stop_btn,podcast_skb)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val binding = CardPodcastBinding.inflate(LayoutInflater.from(context), parent, false)

        return ViewHolder(binding)
    }
    override fun getItemCount(): Int {
       return asyncListDiffer.currentList.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        if (position == currentIndicatorPosition) {
            //Highlight view
        }
            holder.bind(asyncListDiffer.currentList[position])
    }
    override fun getItemViewType(position: Int): Int {
        return itemCount
    }
}




