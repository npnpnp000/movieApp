package com.movieapp.repositories

import androidx.lifecycle.LiveData
import com.movieapp.Models.MovieModel
import com.movieapp.request.MovieApiClient

class MoviesRepository(){
    companion object{
        val instances = MoviesRepository()
        }
    fun getMovies() : LiveData<ArrayList<MovieModel?>> =MovieApiClient.instances.mMovies
    /*suspend */fun searchMovieByTag(key: String, language: String, tag: String, page: Int) {
        MovieApiClient.instances.searchMoviesApi(key, language,tag,page)
    }

}