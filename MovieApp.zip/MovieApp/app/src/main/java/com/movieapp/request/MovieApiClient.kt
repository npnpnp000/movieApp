package com.movieapp.request

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.movieapp.Models.MovieModel
import com.movieapp.response.MoviesSearchResponse
import kotlinx.coroutines.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException

// Live Data
class MovieApiClient(var mMovies : MutableLiveData<ArrayList<MovieModel?>> = MutableLiveData()) {
    companion object{
        val instances = MovieApiClient()
    }
    var job :Job? =null
      /* suspend */fun  searchMoviesApi(key: String,language: String, tag : String, page :Int ){
            val movieApi = Servicey.instances.movieApi
            val exceptionHandler = CoroutineExceptionHandler{_ , throwable->
                throwable.printStackTrace()
            }
           var responseCall: Call<MoviesSearchResponse>? = null
            job = CoroutineScope(Dispatchers.IO + exceptionHandler ).launch{
//           withContext(Dispatchers.IO + exceptionHandler,{
                Log.e( "test","key: $key language: $language tag: $tag page: $page" )
//                val responseCall: Call<MoviesSearchResponse> = movieApi
                        responseCall =movieApi
                    .searchMovisByTag(
                        tag,
                        key,
                        language,
                        page.toString()
                    )
           }
//           )
          job!!.invokeOnCompletion {
           Log.e( "response",responseCall!!.request().url().url().toString())
                responseCall?.enqueue(object : Callback<MoviesSearchResponse> {
                    override fun onResponse(
                        call: Call<MoviesSearchResponse>,
                        response: Response<MoviesSearchResponse>
                    ) {
                        Log.e( "response","key: $key language: $language tag: $tag page: $page" )
                        Log.e( "response",response.code().toString() )
                        if(response.code() == 200){
                            Log.e( "test",response.body()!!.toString() )
                            val movies = response.body()!!.getMovies()
                            Log.e( "response",movies.toString() )
                            movies.add(null)
                            if (page == 1){
                               instances.mMovies.postValue(movies)
                            }else{
                                val currentMovies = instances.mMovies.value
                                currentMovies?.remove(currentMovies.last())
                                currentMovies?.addAll(movies)
                                instances.mMovies.postValue(currentMovies)
                            }
                            instances.mMovies.value?.forEach {
                                Log.e( "test","name: ${it?.title}" )
                            }
                        }else{
                            try{
                                Log.e( "test","Exception" )
                            }catch (e : IOException){
                                e.stackTrace
                            }
                        }

                    }

                    override fun onFailure(call: Call<MoviesSearchResponse>, t: Throwable) {
                        Log.e( "onFailure",t.stackTraceToString())
                    }
                })
          }
            }

    }
//}
