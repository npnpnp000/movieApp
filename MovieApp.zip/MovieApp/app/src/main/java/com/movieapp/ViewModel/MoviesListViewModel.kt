package com.movieapp.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.movieapp.Models.MovieModel

//ViewModel Class
class MoviesListViewModel(var mMovies : MutableLiveData<ArrayList<MovieModel>> = MutableLiveData()) : ViewModel(){

}