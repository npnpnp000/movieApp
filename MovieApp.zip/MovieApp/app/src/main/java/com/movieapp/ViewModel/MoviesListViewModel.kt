package com.movieapp.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.movieapp.Models.MovieModel
import com.movieapp.repositories.MoviesRepository
import com.movieapp.request.MovieApiClient

//ViewModel Class
class MoviesListViewModel() : ViewModel() {

    fun getMovies(): LiveData<ArrayList<MovieModel?>> = MoviesRepository.instances.getMovies()
   /* suspend*/ fun searchMovieByTag(key: String, language: String, tag: String, page: Int) {
        MoviesRepository.instances.searchMovieByTag(key, language,tag,page)
    }
}