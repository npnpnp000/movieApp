package com.movieapp.Models

data class Tab(val tab: String)
