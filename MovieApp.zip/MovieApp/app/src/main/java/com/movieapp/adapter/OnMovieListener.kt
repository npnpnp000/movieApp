package com.movieapp.adapter


interface OnMovieListener {

    fun onMovieClick(position: Int)
}