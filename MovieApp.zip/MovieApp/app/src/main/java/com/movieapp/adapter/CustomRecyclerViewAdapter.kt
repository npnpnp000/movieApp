package com.movieapp.adapter

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.movieapp.Models.Tab
import com.nshmura.recyclertablayout.RecyclerTabLayout

public class CustomRecyclerViewAdapter( viewPager :ViewPager) :
    RecyclerTabLayout.Adapter<CustomRecyclerViewAdapter.ViewHolder>(viewPager){


    public class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(tab: Tab) {}
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate your view.
        return  ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        // Bind data
        if (position == currentIndicatorPosition) {
            //Highlight view
        }
    }

    override fun getItemCount(): Int {
        return itemCount
    }
}