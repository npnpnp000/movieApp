package com.movieapp

import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.CircularProgressDrawable
import com.bumptech.glide.Glide
import com.movieapp.databinding.FragmentDetailsBinding

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private const val ARG_PARAM3 = "param3"
private const val ARG_PARAM4 = "param4"
private const val ARG_PARAM5 = "param5"
private const val ARG_PARAM6 = "param6"

class DetailsFragment : Fragment() {

    private var binding: FragmentDetailsBinding? =null
    private var movieId: Int? = null
    private var posterPath: String? = null
    private var title: String? = null
    private var movieOverview: String? = null
    private var voteAverage: Float? = null
    private var releasedDate: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            movieId = it.getInt(ARG_PARAM1)
            posterPath = it.getString(ARG_PARAM2)
            title = it.getString(ARG_PARAM3)
            movieOverview = it.getString(ARG_PARAM4)
            voteAverage = it.getFloat(ARG_PARAM5)
            releasedDate = it.getString(ARG_PARAM6)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDetailsBinding.inflate(inflater, container, false)
        val view = binding!!.root

        binding!!.dateTxt.text = releasedDate
        binding!!.descriptionTxt.text =
            movieOverview
        binding!!.detailsTitleTxt.text = title
        binding!!.ratingRtb.rating = voteAverage!! / 2

        val url = "https://image.tmdb.org/t/p/w500/${posterPath}" //basic path to get images + specific end path from the movie
        Glide.with(requireContext())
            .load(url)
            .placeholder(circularProgressDrawable())
            .error(ContextCompat.getDrawable(requireContext().applicationContext, R.drawable.ic_baseline_image_not_supported_40 ))
            .into(binding!!.detailsImg)

        return view
    }
    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
    companion object {
        @JvmStatic
        fun newInstance(
            movieId: Int,
            posterPath: String,
            title: String,
            movieOverview: String,
            voteAverage: Float,
            releasedDate: String
        ) =
            DetailsFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_PARAM1, movieId)
                    putString(ARG_PARAM2, posterPath)
                    putString(ARG_PARAM3, title)
                    putString(ARG_PARAM4, movieOverview)
                    putFloat(ARG_PARAM5, voteAverage)
                    putString(ARG_PARAM6, releasedDate)
                }
            }
    }
    private fun circularProgressDrawable(): Drawable {
        val circularProgressDrawable = CircularProgressDrawable(requireContext())
        circularProgressDrawable.strokeWidth = 5f
        circularProgressDrawable.centerRadius = 30f
        circularProgressDrawable.start()
        return circularProgressDrawable

    }
}