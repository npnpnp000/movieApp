package com.movieapp.Models

class FavoriteModel(var category_name :String, var page: Int, var id : String) {
}