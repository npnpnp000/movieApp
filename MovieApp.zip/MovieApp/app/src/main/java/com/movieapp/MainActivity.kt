package com.movieapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.movieapp.Models.MovieModel
import com.movieapp.ViewModel.MoviesListViewModel
import com.movieapp.request.Servicey
import com.movieapp.response.MoviesSearchResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private var moviesListVM : MoviesListViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        moviesListVM = ViewModelProvider(this).get(MoviesListViewModel::class.java )


        GetRetrofitResponse(getString(R.string.def_page,),"upcoming")
    }

    //Observing data change
    fun ObserverOfChange(){
        moviesListVM!!.mMovies.observe(this, object : Observer<ArrayList<MovieModel>>{
            override fun onChanged(t: ArrayList<MovieModel>?) {

            }
        })

    }

    private fun GetRetrofitResponse(page : String, tag : String) {

        val movieApi = Servicey.movieApi

        val responseCall: Call<MoviesSearchResponse> = movieApi
            .searchMovisByTag(
                tag,
                getString(R.string.key),
                getString(R.string.def_language),
                page
            )

        responseCall.enqueue(object : Callback<MoviesSearchResponse>{
            override fun onResponse(
                call: Call<MoviesSearchResponse>,
                response: Response<MoviesSearchResponse>
            ) {
                if(response.code() == 200){
                    Log.e( "test",response.body()?.getMovies().toString() )

                    val movies = response.body()!!.getMovies()

                    movies.forEach {
                        Log.e( "test","name: ${it.title}" )
                    }
                }else{
                    try{
                        Log.e( "test","Exception" )
                    }catch (e : IOException){
                        e.stackTrace
                    }
                }

            }

            override fun onFailure(call: Call<MoviesSearchResponse>, t: Throwable) {
                Log.e( "onFailure","Exception" )
            }
        })

    }
}