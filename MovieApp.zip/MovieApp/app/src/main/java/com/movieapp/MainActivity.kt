package com.movieapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.movieapp.Models.MovieModel
import com.movieapp.Models.Category
import com.movieapp.ViewModel.MoviesListViewModel
import com.movieapp.adapter.MovieMainAdapter
import com.movieapp.adapter.OnMovieListener
import com.movieapp.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private var moviesListVM: MoviesListViewModel? = null
    private lateinit var binding: ActivityMainBinding
    private lateinit var movies_recyclerView_adapter: MovieMainAdapter
    private var current_page = 1
    private var selected_category = Category.top_rated.name
    private var isLoading = false
    private val categoryList = Category.values()
    val START_ID = 1000


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // get ViewModel
        moviesListVM = ViewModelProvider(this)[MoviesListViewModel::class.java]

        setTitle(Category.top_rated.title) // set first title

        setTabs()                         // all tab setting

        setMoviesRecyclerView()          // all sets of the movies list

        ObserverOfChange()

    }

    private fun setTitle(text : String) {
        binding.mainTitleTxt.text = text
    }

    private fun setTabs() {

        dynamicSetTabs()        //dynamic set tabs for adding categories easily

        setTabsListener()       // set tabs behavior
    }

    private fun setTabsListener() {
        binding.tabTbl.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                for (i in 0 until categoryList.size) {                    // search category
                    if (tab!!.id - START_ID == categoryList[i].ordinal) { // if selected tab  (id - 1000) equal to category

                        selected_category = categoryList[i].name         // set the category
                        current_page = 1                                 // set page to the first

                        setTitle( categoryList[i].title)                // set maine title

                        searchMovieByTag(                              // make new data request
                            getString(R.string.key),
                            getString(R.string.def_language),
                            selected_category,
                            current_page
                        )
                        break                                         // stop loop
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }
        })
    }

    private fun dynamicSetTabs() {
        for (i in 0 until categoryList.size) {
            val tab: TabLayout.Tab = binding.tabTbl.newTab()  // create tabs as the number of categories
            tab.id = START_ID + categoryList[i].ordinal       // id: 1000+ category ordinal
            tab.text = categoryList[i].tab_nmae              // tab Text: category text
            binding.tabTbl.addTab(tab)                       // add to the view
        }
    }

    private fun setMoviesRecyclerView() {
        //set adapter and click listener
        movies_recyclerView_adapter = MovieMainAdapter(this, object : OnMovieListener {
            override fun onMovieClick(position: Int) {
                Log.e("onMovieClick", "Go to movie $position ")
            }
        })
        // set the layoutManager to horizontal list
        binding.moviesRcv.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        // loading data for the first time
        searchMovieByTag(
            getString(R.string.key),
            getString(R.string.def_language),
            selected_category,
            current_page
        )
        initScrollListener()
    }

    //    Observing data change
    fun ObserverOfChange() {
        moviesListVM!!.getMovies().observe(this, object : Observer<ArrayList<MovieModel?>> {
            override fun onChanged(list: ArrayList<MovieModel?>?) {
                if (list != null) {
                    list.forEach {
                        Log.e("test", "name: ${it?.title}")
                    }
                } else {
                    Log.e("test", "empty  ")
                }
                if (current_page != 1) {                     //if current_page = 1 this is new category and need refresh the list else is new page and need to save the position
                    val recyclerViewState =
                        binding.moviesRcv.getLayoutManager() // save position of the list
                            ?.onSaveInstanceState()
                    setRecyclerViewAdapter(list!!)           // set new data to the Recycler View
                    binding.moviesRcv.getLayoutManager()
                        ?.onRestoreInstanceState(recyclerViewState)   // fix the list position after refresh to the data to the saved position
                } else {
                    setRecyclerViewAdapter(list!!)
                }

                isLoading = false
            }
        })
    }

    private fun setRecyclerViewAdapter(list: ArrayList<MovieModel?>) {
        binding.moviesRcv.adapter = movies_recyclerView_adapter // set new Adapter
        movies_recyclerView_adapter.setData(list)               // add the new data
    }

    fun searchMovieByTag(key: String, language: String, tag: String, page: Int) {
        isLoading = true  // flag start loading data
        moviesListVM?.searchMovieByTag(key, language, tag, page) // viewModel data request

    }

    private fun initScrollListener() {          // set the lisiner to the end page
        binding.moviesRcv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
            }
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val linearLayoutManager = recyclerView.layoutManager as LinearLayoutManager?

                if (!isLoading) {               // do only if not loading data
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == moviesListVM!!.getMovies().value!!.size - 1) { //bottom of list!
                        current_page += 1       // new page
                        searchMovieByTag(       //request the data of the page
                            getString(R.string.key),
                            getString(R.string.def_language),
                            selected_category,
                            current_page
                        )

                    }
                }
            }
        })
    }
}