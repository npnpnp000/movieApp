package com.movieapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.movieapp.Models.MovieModel
import com.movieapp.ViewModel.MoviesListViewModel
import com.movieapp.databinding.ActivityMainBinding
import com.movieapp.repositories.MoviesRepository
import com.movieapp.request.Servicey
import com.movieapp.response.MoviesSearchResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private var moviesListVM : MoviesListViewModel? = null

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        moviesListVM = ViewModelProvider(this)[MoviesListViewModel::class.java]

//        binding.btn.setOnClickListener {
//            searchMovieByTag(getString(R.string.key),getString(R.string.def_language),"latest",1)
//        }
//        searchMovieByTag(getString(R.string.key),getString(R.string.def_language),"latest",1)
//        //colling the observers
//        ObserverOfChange()

        GetRetrofitResponse(getString(R.string.def_page,),"upcoming")
    }

    //Observing data change
    fun ObserverOfChange(){
        moviesListVM!!.getMovies().observe(this, object : Observer<ArrayList<MovieModel>>{
            override fun onChanged(list: ArrayList<MovieModel>?) {
                if(list != null ){
                    list.forEach {
                        Log.e( "test","name: ${it.title}" )
                    }
                }else{
                    Log.e( "test","empty  " )
                }
            }
        })

    }

    fun searchMovieByTag(key: String, language: String, tag: String, page: Int) {
        moviesListVM?.searchMovieByTag(key, language,tag,page)
    }

    private fun GetRetrofitResponse(page : String, tag : String) {

        val movieApi = Servicey.instances.movieApi

        val responseCall: Call<MoviesSearchResponse> = movieApi
            .searchMovisByTag(
                tag,
                getString(R.string.key),
                getString(R.string.def_language),
                page
            )

        responseCall.enqueue(object : Callback<MoviesSearchResponse>{
            override fun onResponse(
                call: Call<MoviesSearchResponse>,
                response: Response<MoviesSearchResponse>
            ) {
                if(response.code() == 200){
                    Log.e( "test",response.body()?.getMovies().toString() )

                    val movies = response.body()!!.getMovies()

                    movies.forEach {
                        Log.e( "test","name: ${it.title}" )
                    }
                }else{
                    try{
                        Log.e( "test","Exception" )
                    }catch (e : IOException){
                        e.stackTrace
                    }
                }

            }

            override fun onFailure(call: Call<MoviesSearchResponse>, t: Throwable) {
                Log.e( "onFailure",t.stackTraceToString())
            }
        })

    }
}