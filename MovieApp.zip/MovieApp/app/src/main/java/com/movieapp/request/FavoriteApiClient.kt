package com.movieapp.request

import androidx.lifecycle.MutableLiveData
import com.movieapp.Models.FavoriteModel

class FavoriteApiClient(var mFavorites: MutableLiveData<HashMap<String, FavoriteModel>> = MutableLiveData()) {
    companion object {
        val instances = FavoriteApiClient()
    }
    fun addToFavorites(category_name: String, page: Int, id: String) {
        if (!mFavorites.value!!.contains(id)) {
            var new_favorites = hashMapOf<String, FavoriteModel>()
            new_favorites = mFavorites.value!!
            new_favorites.put(id, FavoriteModel(category_name, page, id))
            mFavorites.postValue(new_favorites)
        }
    }
    fun removeFavorites(id: String) {
        if (mFavorites.value!!.contains(id)) {
            var new_favorites = hashMapOf<String, FavoriteModel>()
            new_favorites = mFavorites.value!!
            new_favorites.remove(id)
            mFavorites.postValue(new_favorites)
        }
    }
    fun requestFavorites() {
        mFavorites.postValue(mFavorites.value)
    }
}